## Pedometer 1.1f1
+ Removed GPS backend.

## Pedometer 1.0f1
+ First release.